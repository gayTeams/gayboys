﻿package com.gay;

public class gay {
public static void main(String[] args) {
	System.out.println("欢迎加入亚洲最大同性交友群组：群组成员如下：（昵称）");
	System.out.println("QMSD");
	System.out.println("欢迎来到qm的亚洲max gayTeams");
	System.out.println("I'm Freedomhreat");
}
}
